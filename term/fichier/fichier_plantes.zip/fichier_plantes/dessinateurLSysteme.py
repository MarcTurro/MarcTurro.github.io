import turtle as tt
from pile import *

def turtle_get_state() :
    # renvoie un tuple contenant la position et l'orientation de la tortue
    pass  # code à compléter

def turtle_set_state(state) :
    # positionne et oriente la tortue selon les informations du tuple state
    # Attention à lever le crayon avant de positionner et à le baisser ensuite
    pass # code à compléter

class Dessinateur :

    def __init__(self, longueur,angle) :
        self.longueur = longueur        # longueur des segments 
        self.angle = angle              # angle 
        self.pile = Pile() # pile pour les positions de la tortue

        # dictionnaire associant à chaque caractère la fonction à exécuter
        # code à compléter
        self.commands = { 'F' : self.avancer,
                          'f' : None
                          
                           }

    def avancer(self) :
        """ fait avancer la tortue de la longueur définie dans self.longueur """
        tt.forward(self.longueur)  
    
    def avancer_sans_dessiner(self) :
        """ fait avancer la tortue de la longueur définie dans self.longueur 
            mais sans dessiner 
        """
        pass # code à compléter

    def tourner_droite(self) :
        """ tourne la tortue à droite  de l'angle défini dans  self.angle """
        tt.right(self.angle)

    # code à compléter
    def tourner_gauche(self) :
        """ tourne la tortue à droite  de l'angle défini dans  self.angle """
        
        pass # code à compléter

    def memoriser_position(self) :
        """ mémorise l'état de la tortue, (position, orientation)  dans la pile self.pile"""
        
        pass # code à compléter

    def revenir_memoire(self) :
        """ ramène la tortue à la dernière position mémorisée """

        pass # code à compléter 

    def bourgeon(self) :
        """ dessine un bourgeon, ici sous forme de carré vert 
            code adaptable pour dessiner d'autres choses
        """
        b_size = 4              # taille du carré
        tt.fillcolor('green')   # couleur de remplissage     
        tt.begin_fill()         # indique le début du remplissage
        tt.left(45)
        for i in range(4) :     # dessin des 4 cotés du carré
            tt.forward(b_size)
            tt.right(90)
            tt.right(45)        
        tt.end_fill()           # indique la fin du remplissage

    def dessiner(self, chaine) :
        """ exécute les commandes associées à chaque caractère de la chaîne passée en argument """ 
        tt.speed(0)     # diminue à 1 le delai entre chaque mouvement de tortue

        for car in chaine :
            pass  # code à compléter, utiliser le dictionnaire self.commands

        tt.exitonclick()

    


