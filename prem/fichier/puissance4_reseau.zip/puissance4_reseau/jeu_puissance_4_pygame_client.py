import pygame, sys, socket
from pygame.locals import *
from gain_jeu import *



adresseIP = ".................."  # The server's hostname or IP address
port = 50000 # The port used by the server


pygame.init()

#----- CONSTANTE DU JEU --------------------#
BLEU = (0, 0, 255)
WHITE = (255, 255, 255)
JAUNE = (255, 255, 0)
ROUGE = (255, 0, 0)
tour = 0
mem = [0 for i in range(7)]
place_jeton_jaune = []
place_jeton_rouge = []
gain_j = 0
gain_r = 0
flag = 0

#-------  MUSIQUE  ----------------#
pygame.mixer.init()
pygame.mixer.set_num_channels(1)
bruitage = "./son/bruit.wav"
bruit = pygame.mixer.Sound(bruitage)
ch1 = pygame.mixer.find_channel()


# ----- INITIALISATION CONSTRUCTEURS-------------------  #


screen = pygame.display.set_mode( (700, 600))
icon = pygame.image.load("logoNSI.ico")

pygame.display.set_icon(icon)
pygame.display.set_caption("Puissance 4")

screen.fill(BLEU)
for j in range(6):
    for i in range(7):
        pygame.draw.circle(screen, WHITE, (50 + 100*i, 50 + 100*j), 40)
pygame.display.update()
        
#  ---     FONCTIONS    -----------         #
def cible(valeur):
    for i in range(7):
        if 100*i < valeur <100*(i + 1):
            valeur = (100*i + 100*(i + 1))//2
    return valeur


client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((adresseIP, port))

message = "Prêt pour jouer!"
client.send(message.encode("utf-8"))


while True:
    reponse = client.recv(255)
    position_serveur = reponse.decode("utf-8")
    print(position_serveur)
    ch1.play(bruit)
    x = position_serveur.split(',')[0][1:]
    y = position_serveur.split(',')[1][:-1]
    pygame.draw.circle(screen, JAUNE, (int(x),int(y)), 40)
    place_jeton_jaune.append((x, y))
    tour +=1
    mem[int(x)//100] += 1
    pygame.display.update()
    flag_joueur = True
    while flag_joueur:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                print("clic fonctionne")
                x, y = cible(event.pos[0]), 550 - mem[event.pos[0]//100]*100
                pygame.draw.circle(screen, ROUGE, (x, y), 40)
                place_jeton_rouge.append((x, y))
                client.send(f"{(x, y)}".encode("utf-8"))
                ch1.play(bruit)
                if gain_vertical(x, y, place_jeton_jaune) or gain_horizontal(x, y, place_jeton_jaune) or gain_diagonal_1(x, y, place_jeton_jaune) or gain_diagonal_2(x, y, place_jeton_jaune):
                    print("Jaune a gagné")
                    ch1.stop()
                    flag = 1
                if gain_vertical(x, y, place_jeton_rouge) or gain_horizontal(x, y, place_jeton_rouge) or gain_diagonal_1(x, y, place_jeton_rouge) or gain_diagonal_2(x, y, place_jeton_rouge):
                    print("Rouge a gagné")
                    ch1.stop()
                    flag = 1
                mem[event.pos[0]//100] += 1
                flag_joueur = False
    pygame.display.update()
