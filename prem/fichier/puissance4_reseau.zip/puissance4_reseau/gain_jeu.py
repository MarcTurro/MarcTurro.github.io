def gain_vertical(x, y , liste):
    gain = 0    
    for i in range(4):
        if (x, y + 100*i) in liste:
            gain += 1
            if gain == 4:
                return True            
        else:
            return False
def gain_horizontal(x, y, liste):
    gain = 0
    for i in range(4):
        if (x + 100*i, y) in liste:
            gain += 1
        else:
            break
    for i in range(3):
        if (x - 100*(i + 1), y) in liste:
            gain += 1
        else:
            break
    if gain >= 4:
        return True
    else:
        return False
def gain_diagonal_1(x, y, liste):
    gain = 0
    for i in range(4):
        if (x + 100*i, y + 100*i) in liste:
            gain += 1
        else:
            break
    for i in range(3):
        if (x - 100*(i + 1), y - 100*(i + 1)) in liste:
            gain += 1
        else:
            break
    if gain >= 4:
        return True
    else:
        return False

def gain_diagonal_2(x, y, liste):
    gain = 0
    for i in range(4):
        if (x + 100*i, y - 100*i) in liste:
            gain += 1
        else:
            break
    for i in range(3):
        if (x - 100*(i + 1), y + 100*(i + 1)) in liste:
            gain += 1
        else:
            break
    if gain >= 4:
        return True
    else:
        return False