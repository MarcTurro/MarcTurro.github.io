import pygame, sys, socket
from pygame.locals import *
from gain_jeu import *
#from tous_les_sons import *

#------------------------------------------------------------#
#              CREATION DU SERVEUR                           #
#------------------------------------------------------------#

serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serveur.bind(('', 50000))    # Écoute sur le port 50000
serveur.listen(5)
client, adress = serveur.accept()
print("Client connecté. Adresse " + adress[0])
requete = client.recv(255)  
print(requete.decode("utf-8"))

pygame.init() # on démarre pygame
#----- CONSTANTE DU JEU --------------------#
BLEU = (0, 0, 255)
WHITE = (255, 255, 255)
JAUNE = (255, 255, 0)
ROUGE = (255, 0, 0)
tour = 0
mem = [0 for i in range(7)]
place_jeton_jaune = []
place_jeton_rouge = []
gain_j = 0
gain_r = 0
flag = 0

#----          MUSIQUE --------#
pygame.mixer.init()
pygame.mixer.set_num_channels(1)

bruitage = "./son/bruit.wav"
bruit = pygame.mixer.Sound(bruitage)
ch1 = pygame.mixer.find_channel()



# ----- INITIALISATION CONSTRUCTEURS-------------------  #
screen = pygame.display.set_mode( (700, 600))
icon = pygame.image.load("logoNSI.ico")

pygame.display.set_icon(icon)
pygame.display.set_caption("Puissance 4")

screen.fill(BLEU)
for j in range(6):
    for i in range(7):
        pygame.draw.circle(screen, WHITE, (50 + 100*i, 50 + 100*j), 40)
        
#  ---     FONCTIONS    -----------         #
def cible(valeur):
    for i in range(7):
        if 100*i < valeur <100*(i + 1):
            valeur = (100*i + 100*(i + 1))//2
    return valeur

while True:
    flag_joueur = True
    while flag_joueur:
        for event in pygame.event.get():    #pour tous les événements
            if event.type == QUIT:          #si l'événement quit est déclenché
                pygame.quit()
                sys.exit()                  #fin du jeu
            if event.type == pygame.MOUSEBUTTONDOWN:
                if flag == 0:
                    x, y = cible(event.pos[0]), 550 - mem[event.pos[0]//100]*100
                    pygame.draw.circle(screen, JAUNE, (x, y), 40)
                    ch1.play(bruit)
                    place_jeton_jaune.append((x, y))
                    client.send(f"{(x, y)}".encode("utf-8"))
                    if gain_vertical(x, y, place_jeton_jaune) or gain_horizontal(x, y, place_jeton_jaune) or gain_diagonal_1(x, y, place_jeton_jaune) or gain_diagonal_2(x, y, place_jeton_jaune):
                        print("Jaune a gagné")
                        ch1.stop()
                        flag = 1
                    if gain_vertical(x, y, place_jeton_rouge) or gain_horizontal(x, y, place_jeton_rouge) or gain_diagonal_1(x, y, place_jeton_rouge) or gain_diagonal_2(x, y, place_jeton_rouge):
                        print("Rouge a gagné")
                        ch1.stop()
                        flag = 1
                    flag_joueur = False
                    mem[event.pos[0]//100] += 1
            pygame.display.update()
    requete = client.recv(255)  
    position_client = requete.decode("utf-8")
    print(position_client)
    x = position_client.split(',')[0][1:]
    y = position_client.split(',')[1][:-1]
    pygame.draw.circle(screen, ROUGE, (int(x), int(y)), 40)
    ch1.play(bruit)
    place_jeton_rouge.append((int(x), int(y)))
    mem[int(x)//100] += 1
    pygame.display.update()
    
    
    
    
