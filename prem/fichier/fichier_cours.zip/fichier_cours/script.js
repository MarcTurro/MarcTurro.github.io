function ajaxGet(url, callback) {
    var req = new XMLHttpRequest();
    req.open("GET", url);
    req.addEventListener("load", function () {
        if (req.status >= 200 && req.status < 400) {
            // Appelle la fonction callback en lui passant la réponse de la requête
            callback(req.responseText);
        } else {
            console.error(req.status + " " + req.statusText + " " + url);
        }
    });
    req.addEventListener("error", function () {
        console.error("Erreur réseau avec l'URL " + url);
    });
    req.send(null);
}

var form = document.querySelector("form");
form.addEventListener("submit", function(e){
  e.preventDefault();

  var city = form.elements.cityName.value;
  console.log(city);
  var lang = "&lang=fr";
  var temp = "&units=metric";
  var API_KEY = "&APPID=...........";
  
  ajaxGet("http://api.openweathermap.org/data/2.5/weather?q=" + city + API_KEY + lang + temp, function (reponse) {
      var data = JSON.parse(reponse);
      console.log(data);

      var cityName = document.createElement("h2");
      cityName.textContent = data.name;

      var temperature = document.createElement("h2");
      temperature.textContent = data.main.temp + "°C";
      
      document.getElementById("resp").appendChild(cityName);
      document.getElementById("resp").appendChild(temperature);
      
  });
});